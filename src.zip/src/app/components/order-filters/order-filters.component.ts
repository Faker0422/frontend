import { Component } from '@angular/core';

@Component({
  selector: 'app-order-filters',
  standalone: false,
  templateUrl: './order-filters.component.html',
  styleUrl: './order-filters.component.css'
})
export class OrderFiltersComponent {

}
