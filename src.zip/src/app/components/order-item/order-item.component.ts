import { Component, Input } from '@angular/core';
import { OrderItem } from '../../models/order'; // Make sure this import is correct
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-item',
  standalone: false,
  templateUrl: './order-item.component.html',
  styleUrl: './order-item.component.css'
})
export class OrderItemComponent {
  @Input() orderItem!: OrderItem;
  @Input() deliveryDate?: string;  // <--- **Double check this line is EXACTLY like this**
}