import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpInterceptor } from '@angular/common/http';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    // **Important: Replace 'YOUR_JWT_TOKEN_HERE' with your actual token retrieval logic**
    const token = 'eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJKYW5lIFNtaXRoIiwiaWF0IjoxNzM5OTM5OTM4LCJleHAiOjE3Mzk5NDE3Mzh9.O7isuq9ZdsL8Qpc1iMdmOZEJv3cFzrhDfmrkxYUSzb_y2kQnNrMs6WdWhnZn5y0a'; //  <-- Replace this placeholder

    if (token) {
      // Clone the request and add the Authorization header with the JWT token
      const authRequest = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}` // Standard JWT Authorization header format
        }
      });
      return next.handle(authRequest); // Pass the modified request to the next interceptor or to the backend
    }

    return next.handle(request); // If no token, proceed with the original request
  }
}