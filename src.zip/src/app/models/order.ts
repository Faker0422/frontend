
export interface Order {
    orderId: number;
    userId: number;
    totalAmount: number;
    orderStatus: string;
    deliveryAddress: Address; // Full address object
    deliveryDate: string;
    createdAt: string;
    orderItems: OrderItem[];
  }
  
  export interface Address {
    addressId: number;
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  }
  
  export interface OrderItem {
    orderItemId: number;
    productId: number;
    productName: string;
    quantity: number;
    price: number;
    discount: number;
    createdAt: string;
    image: string;
  }
  
  