import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { AppComponent } from './app.component';
import { OrderHistoryComponent } from './components/order-history/order-history.component';
import { OrderItemComponent } from './components/order-item/order-item.component';
import { OrderFiltersComponent } from './components/order-filters/order-filters.component';
import { AppRoutingModule } from './app-routing.module';
import { CommonModule } from '@angular/common';
// import { HTTP_INTERCEPTORS } from '@angular/common/http'; // Import HTTP_INTERCEPTORS
// import { JwtInterceptor } from './interceptor/jwt.interceptor'; // Import your JwtInterceptor


@NgModule({
  declarations: [
    AppComponent,
    OrderHistoryComponent,
    OrderItemComponent,
    OrderFiltersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule
  ],
  providers: [
    provideHttpClient(),
    // {
    //   provide: HTTP_INTERCEPTORS,  // Provide HTTP_INTERCEPTORS token
    //   useClass: JwtInterceptor,     // Use JwtInterceptor class
    //   multi: true                 // multi: true to allow multiple interceptors
    // }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }